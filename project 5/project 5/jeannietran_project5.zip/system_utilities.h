int parseCommandLine(char cline[], char *tklist[]);

int convertIntToValue(char *s);

int getCommandNumber(char *s);

void fillSystemCommandList();