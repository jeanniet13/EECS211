#ifndef EVENTS_H
#define EVENTS_H


/*
	Event class declaration.
	
	Author:		Larry Henschen
	Created:	December 31, 2011
	Last Modified:	December 31, 2011
	
	Events include the name of the device, the type of event, and the time stamp.
	(Time-stamp 0 means this is urgent and should be processed before any other 
	events.  Events are order be increasing time stamp.  Some events will not
	be processed until later times; for example, flashing a turn signal on and off
	happens every 3 seconds, so when it is turned on a new event is added for 3
	seconds later.
	
	An ordered linked list is used to store events.  A separate class is defined
	for the list nodes.

*/


class LIST;
class EVENT;

// Linked list class and node class.
class LLNODE {
//	friend LIST;
	friend class LIST;
	
	private:
		LLNODE *next;
		EVENT  *ev;
		
	public:
		LLNODE();
		LLNODE(EVENT *e);
		~LLNODE();
};

class LIST {
	private:
		LLNODE *front;
		
	public:
		LIST();
		~LIST();
		void display();
		EVENT *getFirstEvent();
		void  removeFirstEvent();
		void insertEvent(EVENT *e);
};



// Event class.

class EVENT {
	private:
		char *device;
		int  value;
		int  processTime;
		
	public:
		EVENT(char *n, int v, int pt);
		~EVENT();
		void display();
		int  getprocessTime();
};


#endif

