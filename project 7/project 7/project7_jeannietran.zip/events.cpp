#include "devices.h"
#include "definitions.h"
#include "events.h"
#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <math.h>

using namespace std;

LLNODE::LLNODE() {}

LLNODE::LLNODE(EVENT *e) {
	ev = e;
	next = NULL;
}

LLNODE::~LLNODE() {  
	free( (char *) ev);
}

//---------------------------------------------------------------------------------------------------


LIST::LIST() {
	front->next = NULL;
	front->ev = NULL;
}

LIST::~LIST() {
	LLNODE* index;
	index->next = front; 
	while (index->next != NULL) {
		index->next = index->next->next;
	}
}

void LIST::display() {
	cout << "Displaying event list:" << endl;
	if(front == NULL) {
		cout << "\t\t\tEMPTY\n\n";
	}
	else if(front->next == NULL) {
		(front-> ev)->display();
		cout << " --> NULL\n\n";
	}
	else {
		do {
			(front->ev)->display();
			cout<< "\n\n --> \n\n";
			front = front -> next;
		} while(front->next != NULL);
		cout << "NULL\n\n";
	}
}

EVENT* LIST::getFirstEvent() {
	if (front != NULL) {
		return ev;
	}
}

void LIST::removeFirstEvent() {
	if (front != NULL) {
		front->next = front->next->next;
		front->ev = front->next->ev;
	}
}

void LIST::insertEvent(EVENT *e) {
	LLNODE* newnode = new LLNODE(e);
	if (front == NULL) {
		front = newnode;
	}
	else {
		LLNODE* beforeptr;
		beforeptr->next = NULL;
		LLNODE* afterptr;
		afterptr->next = front;
		while (afterptr->next != beforeptr->next) {
			if (afterptr->ev < e->ev) {
				break;
			}
			else {
				beforeptr->next = afterptr->next;
				afterptr-> = 
			}
		}
	}
}


//---------------------------------------------------------------------------------------------------

EVENT::EVENT(char *n, int v, int pt) {
	device = (char *) malloc(strlen(n)+1);  //allocate space to hold string n and assign returned address to device name data member
	strcpy(device, n);
	value = v;
	processTime = pt;
}

EVENT::~EVENT() {  //frees memory allocated to hold the name data member 
	free( (char *) device);
}

int EVENT::getprocessTime() {
	return processTime;
}

void EVENT::display() {
	cout << "EVENT:     Device: " << device << "\n";
	cout << "Device value " << value << ".     Scheduled to be processed at " << processTime << ".\n\n\n";
}